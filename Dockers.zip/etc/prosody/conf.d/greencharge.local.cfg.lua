VirtualHost "greencharge.local"
ssl={
    certificate = "/etc/prosody/certs/greencharge.local.crt";
    key = "/etc/prosody/certs/greencharge.local.key";
}
