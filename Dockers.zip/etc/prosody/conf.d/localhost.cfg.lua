-- Section for localhost

-- This allows clients to connect to localhost. No harm in it.
VirtualHost "localhost"
