# dummyscheduler
## Installation
Donwload the repository

```
cd dummyscheduler
npm install
```

## Configuration
Ask for the creation of user and simulator account.

Update into the code:
* jid
* password
* server address
* server port

## Execution
```
node sched.js
```
